/* esm.sh - ultravox-client@0.3.6 */
import "/livekit-client@^2.5.1?target=es2022";
export * from "/ultravox-client@0.3.6/es2022/ultravox-client.mjs";
