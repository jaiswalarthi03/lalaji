import time
import requests
import json
import logging
import re
from typing import Dict, List, Any, Optional
from datetime import datetime

from config import GEMINI_API_KEY
from mongodb import db
from services.store_service import get_active_store
from services.order_service import create_supplier_order

logger = logging.getLogger(__name__)

class ConversationalDistributorService:
    def __init__(self):
        self.api_key = GEMINI_API_KEY
        self.api_url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={self.api_key}"
        self.headers = {
            "Content-Type": "application/json"
        }
        # Add Gemini model initialization for LLM chat
        try:
            # Use the summarize_with_gemini logic as a model wrapper
            from services.gemini_service import summarize_with_gemini
            class GeminiChatModel:
                def __init__(self, model_name=None):
                    self.model_name = model_name or "gemini-2.0-flash"
                def generate_content(self, conversation):
                    # Compose a prompt from the conversation
                    user_msgs = [msg['content'] for msg in conversation if msg['role'] == 'user']
                    prompt = user_msgs[-1] if user_msgs else conversation[-1]['content']
                    # Use store name if available
                    store_name = "Sethji"
                    for msg in conversation:
                        if 'store_name' in msg.get('content',''):
                            store_name = msg['content'].split('store_name')[1].split()[0]
                            break
                    # Use supplier context for distributor chat
                    return type('Resp', (), { 'text': summarize_with_gemini(prompt, store_name, 'supplier') })()
            self.model = GeminiChatModel(model_name="gemini-2.0-flash")
        except Exception as e:
            logger.error(f"Could not initialize GeminiChatModel: {e}")
            self.model = None
        
    def _get_product_context(self) -> str:
        """Get current product context for the AI"""
        try:
            products = list(db.products.find())
            active_store = get_active_store()
            currency = active_store.currency_symbol if active_store else '₹'
            
            context = f"Current inventory at {active_store.store_name if active_store else 'our store'}:\n\n"
            
            for product in products:
                stock_status = "🟢" if product['quantity'] > product['reorder_level'] else "🔴"
                context += f"• {product['name']}: {stock_status} {product['quantity']} units in stock, {currency}{product['cost_price']} cost price"
                if product['quantity'] <= product['reorder_level']:
                    context += f" (LOW STOCK - reorder level: {product['reorder_level']})"
                context += "\n"
            
            # Add low stock summary
            low_stock_items = [p for p in products if p['quantity'] <= p['reorder_level']]
            if low_stock_items:
                context += f"\n🚨 LOW STOCK ALERT: {len(low_stock_items)} items need restocking:\n"
                for item in low_stock_items:
                    context += f"  - {item['name']}: {item['quantity']} units (reorder level: {item['reorder_level']})\n"
            
            return context
            
        except Exception as e:
            logger.error(f"Error getting product context: {e}")
            return "Product information temporarily unavailable."
    
    def _create_system_prompt(self, distributor_name: str) -> str:
        """Create the system prompt for the conversational AI"""
        product_context = self._get_product_context()
        active_store = get_active_store()
        store_name = active_store.store_name if active_store else "our store"
        currency = active_store.currency_symbol if active_store else '₹'
        
        return f"""You are a helpful and professional inventory management assistant for {store_name}. Your name is {store_name} Inventory Manager.

{product_context}

Your role is to:
1. Greet distributors warmly and help them with inventory management
2. Show current stock levels and proactively identify low stock items
3. Help distributors understand what products need restocking
4. Assist distributors in adding stock to inventory through natural conversation
5. Answer questions about products, delivery schedules, and inventory policies
6. Be proactive in suggesting restocking when inventory is low
7. Help distributors fulfill inventory needs efficiently

Guidelines:
- Always be polite and professional
- Use the distributor's name when appropriate
- Proactively show current stock levels and identify items that need restocking
- When stock is low (below reorder level), clearly indicate this to distributors
- Help distributors understand inventory gaps and opportunities
- Provide accurate product information and cost prices
- Help distributors make restocking decisions efficiently
- Confirm order details before finalizing
- Use {currency} for all prices
- Keep responses concise but helpful
- When distributors first chat, show them current inventory status and proactively suggest what needs restocking
- Always mention the store name {store_name} in your responses
- Be proactive: "We're running low on X, could you help us restock?"

IMPORTANT: Distributor orders ADD to inventory (restock), they don't subtract from it. Distributors are suppliers who help maintain inventory levels.

Current distributor: {distributor_name}

Remember: You're having a natural conversation, not following a rigid script. Adapt to the distributor's communication style and needs."""

    def _get_welcome_message(self, distributor_name: str) -> str:
        """Generate a welcoming message that shows inventory status and encourages restocking"""
        try:
            products = list(db.products.find())
            active_store = get_active_store()
            currency = active_store.currency_symbol if active_store else '₹'
            store_name = active_store.store_name if active_store else "our store"
            
            # Calculate low stock items
            low_stock_items = [p for p in products if p['quantity'] <= p['reorder_level']]
            
            # Create beautiful HTML welcome message
            welcome_message = f"""
<div class="welcome-message">
    <h2>👋 Welcome to {store_name}, {distributor_name}!</h2>
    <p>I'm here to help you manage our inventory and identify restocking opportunities.</p>
</div>

<div class="product-showcase">
    <h3>📊 Current Inventory Status</h3>
    <div class="product-grid">
"""
            
            # Show products with stock status
            for i, product in enumerate(products[:6], 1):  # Show first 6 products
                stock_status = "🟢" if product['quantity'] > product['reorder_level'] else "🔴"
                welcome_message += f"""
        <div class="product-card">
            <div class="product-name">{product['name']}</div>
            <div class="product-price">{currency}{product['cost_price']}</div>
            <div class="product-stock">{stock_status} {product['quantity']} units in stock</div>
        </div>
"""
            
            welcome_message += """
    </div>
</div>

<div class="example-commands">
    <h4>💬 How to help us restock:</h4>
    <ul>
        <li>"I want to add 50 Lotte Chocopie"</li>
        <li>"Restock 30 Tata Salt"</li>
        <li>"Add 25 Basmati Rice to inventory"</li>
        <li>"Show me low stock items"</li>
        <li>"What products need restocking?"</li>
    </ul>
</div>

<p style="text-align: center; margin-top: 15px; font-style: italic;">
    🎯 I'm here to help you keep our inventory well-stocked!
</p>
"""
            
            # Add proactive restocking suggestion if there are low stock items
            if low_stock_items:
                welcome_message += f"""
<div class="restock-suggestion" style="background: #fff3cd; border: 1px solid #ffeaa7; border-radius: 10px; padding: 15px; margin: 15px 0;">
    <h4>🚨 Proactive Restocking Alert</h4>
    <p>We're running low on these items and could use your help:</p>
    <ul>
"""
                for item in low_stock_items:
                    welcome_message += f"        <li><strong>{item['name']}</strong>: Only {item['quantity']} units left (Reorder level: {item['reorder_level']})</li>\n"
                
                welcome_message += """
    </ul>
    <p><strong>Could you help us restock these items?</strong></p>
</div>
"""
            
            return welcome_message
            
        except Exception as e:
            logger.error(f"Error generating welcome message: {e}")
            return f"Hi {distributor_name}! Welcome! How can I help you with inventory management today?"

    def _create_conversation(self, messages: List[Dict], distributor_name: str) -> List[Dict]:
        """Create the conversation for Gemini API"""
        try:
            # Create system prompt
            system_prompt = self._create_system_prompt(distributor_name)
            
            # Build conversation messages
            conversation = [{"role": "system", "content": system_prompt}]
            
            # Add conversation history (last 10 messages to keep context manageable)
            for msg in messages[-10:]:
                conversation.append({
                    "role": msg["role"],
                    "content": msg["content"]
                })
            
            return conversation
            
        except Exception as e:
            logger.error(f"Error creating conversation: {e}")
            # Return minimal conversation
            return [
                {"role": "system", "content": f"You are a helpful inventory assistant for {distributor_name}."},
                {"role": "user", "content": messages[-1]["content"] if messages else "Hello"}
            ]

    def _process_conversation(self, messages: List[Dict], distributor_name: str) -> Dict:
        """Process the conversation and generate a response"""
        try:
            # Create the conversation for Gemini
            conversation = self._create_conversation(messages, distributor_name)
            
            # Generate response from Gemini
            response = self.model.generate_content(conversation)
            
            if not response or not response.text:
                return {
                    "response": "I apologize, but I'm having trouble processing your request right now. Could you please try again?",
                    "conversation_ended": False,
                    "order_data": None
                }
            
            response_text = response.text.strip()
            
            # Check for conversation ending
            if self._is_conversation_ending(response_text):
                return {
                    "response": response_text,
                    "conversation_ended": True,
                    "order_data": None
                }
            
            # Check for restock intent
            order_data = self._extract_restock_intent(response_text, messages[-1]["content"] if messages else "")
            
            return {
                "response": response_text,
                "conversation_ended": False,
                "order_data": order_data
            }
            
        except Exception as e:
            logger.error(f"Error processing distributor conversation: {e}")
            return {
                "response": "I apologize, but I'm experiencing technical difficulties. Please try again in a moment.",
                "conversation_ended": False,
                "order_data": None
            }

    def _extract_restock_intent(self, response_text: str, user_message: str) -> Optional[Dict]:
        """Extract restock order intent from the conversation"""
        try:
            # Look for patterns that indicate restocking - improved patterns
            restock_patterns = [
                r"add\s+(\d+)\s+(?:units?\s+of\s+)?([a-zA-Z\s]+)",
                r"restock\s+(\d+)\s+(?:units?\s+of\s+)?([a-zA-Z\s]+)",
                r"(\d+)\s+(?:units?\s+of\s+)?([a-zA-Z\s]+)",
                r"supply\s+(\d+)\s+(?:units?\s+of\s+)?([a-zA-Z\s]+)",
                r"deliver\s+(\d+)\s+(?:units?\s+of\s+)?([a-zA-Z\s]+)",
                r"(\d+)\s+([a-zA-Z\s]+)",  # Simple pattern: "10 Amul Butter"
                r"add\s+(\d+)\s+([a-zA-Z\s]+)",  # "add 10 Amul Butter"
            ]
            
            # Check both user message and AI response for restock intent
            messages_to_check = [user_message, response_text]
            
            for message in messages_to_check:
                for pattern in restock_patterns:
                    matches = re.findall(pattern, message, re.IGNORECASE)
                    if matches:
                        for quantity, product_name in matches:
                            quantity = int(quantity)
                            product_name = product_name.strip()
                            
                            # Find the product in database with better matching
                            product = list(db.products.find({"name": {"$regex": f"^{product_name}$", "$options": "i"}}))
                            
                            if product:
                                return {
                                    "product_id": product[0]['_id'],
                                    "product_name": product[0]['name'],
                                    "quantity": quantity,
                                    "cost_price": float(product[0]['cost_price']),
                                    "total_amount": float(product[0]['cost_price']) * quantity
                                }
            
            # Additional check for common restock phrases
            restock_phrases = [
                "add", "restock", "supply", "deliver", "stock", "inventory"
            ]
            
            user_lower = user_message.lower()
            if any(phrase in user_lower for phrase in restock_phrases):
                # Try to extract quantity and product from the message
                words = user_message.split()
                quantities = [int(word) for word in words if word.isdigit()]
                if quantities:
                    quantity = quantities[0]
                    # Look for product names in the message
                    products = list(db.products.find())
                    for product in products:
                        if product['name'].lower() in user_lower:
                            return {
                                "product_id": product['_id'],
                                "product_name": product['name'],
                                "quantity": quantity,
                                "cost_price": float(product['cost_price']),
                                "total_amount": float(product['cost_price']) * quantity
                            }
            
            return None
            
        except Exception as e:
            logger.error(f"Error extracting restock intent: {e}")
            return None

    def _is_conversation_ending(self, response_text: str) -> bool:
        """Check if the conversation is ending"""
        goodbye_words = [
            "goodbye", "bye", "see you", "thank you", "thanks", "end", "finish", 
            "complete", "done", "that's all", "that is all", "nothing else",
            "good bye", "good-bye", "farewell", "take care", "have a good day",
            "have a great day", "talk to you later", "until next time"
        ]
        
        response_lower = response_text.lower()
        return any(word in response_lower for word in goodbye_words)

    def _call_llm(self, prompt: str, messages: List[Dict] = None) -> str:
        """Call the Gemini API"""
        try:
            if not self.api_key or self.api_key.startswith("your-"):
                return "I'm sorry, but I'm not properly configured to help with inventory management right now. Please contact our support team."
            
            # Build conversation for Gemini - simpler approach
            if messages:
                # Combine system prompt and conversation into a single prompt
                full_prompt = ""
                
                for msg in messages:
                    if msg.get("role") == "system":
                        full_prompt += msg.get("content", "") + "\n\n"
                    elif msg.get("role") == "user":
                        full_prompt += f"Distributor: {msg.get('content', '')}\n"
                    elif msg.get("role") == "assistant":
                        full_prompt += f"Assistant: {msg.get('content', '')}\n"
                
                # Add the current prompt if provided
                if prompt:
                    full_prompt += f"Distributor: {prompt}\nAssistant:"
                else:
                    full_prompt += "Assistant:"
            else:
                # Single prompt
                full_prompt = prompt
            
            data = {
                "contents": [{
                    "parts": [{"text": full_prompt}]
                }],
                "generationConfig": {
                    "maxOutputTokens": 500,
                    "temperature": 0.7
                }
            }
            
            response = requests.post(self.api_url, headers=self.headers, json=data, timeout=30)
            
            if response.status_code == 429:
                logger.warning("Rate limit hit. Waiting 5 seconds...")
                time.sleep(5)
                return self._call_llm(prompt, messages)
            
            response.raise_for_status()
            result = response.json()
            
            # Extract text from Gemini response
            if "candidates" in result and len(result["candidates"]) > 0:
                return result["candidates"][0]["content"]["parts"][0]["text"]
            else:
                return "I'm sorry, I couldn't generate a response at the moment."
            
        except Exception as e:
            logger.error(f"Error calling Gemini API: {e}")
            return "I'm sorry, I'm having trouble processing your request right now. Please try again in a moment."

    def chat(self, message: str, distributor_name: str, conversation_history: List[Dict] = None) -> Dict[str, Any]:
        vague_queries = [
            "how much", "how many", "what's left", "stock", "inventory", "tell me how much", "tell me stock"
        ]
        if any(q in message.lower() for q in vague_queries):
            logger.info(f"Vague query detected: '{message}' from distributor '{distributor_name}'")
            products = list(db.products.find())
            if products:
                response = "Here are the current stock levels:\n"
                for product in products:
                    response += f"- {product['name']}: {product['quantity']} units (Reorder level: {product['reorder_level']})\n"
            else:
                response = "No products found in inventory."
            logger.info(f"Response to vague query: {response}")
            return {
                "response": response,
                "conversation_ended": False,
                "order_processed": False,
                "order_details": None,
                "conversation_history": conversation_history or []
            }
        try:
            if conversation_history is None:
                conversation_history = []
            
            # Add user message to history
            conversation_history.append({
                "role": "user",
                "content": message
            })
            
            # Process the conversation
            result = self._process_conversation(conversation_history, distributor_name)
            
            # Add AI response to history
            conversation_history.append({
                "role": "assistant", 
                "content": result["response"]
            })
            
            # Process restock order if detected
            if result.get("order_data"):
                try:
                    # Use create_supplier_order directly for real database updates
                    order_result = create_supplier_order(
                        supplier_name=distributor_name,
                        items_data=[{
                            "product_id": result["order_data"]["product_id"],
                            "quantity": result["order_data"]["quantity"]
                        }]
                    )
                    
                    if order_result:
                        # Get updated product info for confirmation
                        product = list(db.products.find({"_id": result["order_data"]["product_id"]}))
                        new_quantity = product[0]['quantity'] if product else 0
                        
                        # Update the response to include real order confirmation
                        result["response"] = f"Perfect! I've successfully processed your restock order:\n\n"
                        result["response"] += f"✅ **Order Processed Successfully!**\n"
                        result["response"] += f"• Added {result['order_data']['quantity']} units of {result['order_data']['product_name']}\n"
                        result["response"] += f"• Total cost: ₹{result['order_data']['total_amount']:.2f}\n"
                        result["response"] += f"• New stock level: {new_quantity} units\n"
                        result["response"] += f"• Order ID: #{order_result.id}\n\n"
                        result["response"] += f"Thank you for helping us maintain our inventory, {distributor_name}!"
                        
                        # Update conversation history with the enhanced response
                        conversation_history[-1]["content"] = result["response"]
                        result["order_processed"] = True
                        result["order_details"] = {
                            "order_id": order_result.id,
                            "new_quantity": new_quantity,
                            "total_amount": result['order_data']['total_amount']
                        }
                    else:
                        result["response"] += f"\n\n❌ **Order Processing Failed:** Unable to create order in database"
                        result["order_processed"] = False
                        
                except Exception as e:
                    logger.error(f"Error processing distributor order: {e}")
                    result["response"] += f"\n\n❌ **Order Processing Error:** {str(e)}"
                    result["order_processed"] = False
            
            return {
                "response": result["response"],
                "conversation_ended": result.get("conversation_ended", False),
                "order_processed": result.get("order_processed", False),
                "order_details": result.get("order_details"),
                "conversation_history": conversation_history
            }
            
        except Exception as e:
            logger.error(f"Error in distributor chat: {e}")
            return {
                "response": "I apologize, but I'm experiencing technical difficulties. Please try again in a moment.",
                "conversation_ended": False,
                "order_processed": False,
                "order_details": None,
                "conversation_history": conversation_history or []
            }

    def process_message(self, distributor_id, message, conversation_history):
        """Process a distributor message using the distributor's name from the database."""
        try:
            from mongodb import db
            distributor = db.distributors.find_one({'_id': distributor_id})
            distributor_name = distributor['name'] if distributor and 'name' in distributor else f"Distributor {distributor_id}"
        except Exception as e:
            distributor_name = f"Distributor {distributor_id}"
        return self.chat(message, distributor_name, conversation_history)

# Global instance
distributor_service = ConversationalDistributorService() 